import { Text, Touchable } from "react-native"
import { SafeAreaProvider } from "react-native-safe-area-context"
export default function Login(){
    return(
        <SafeAreaProvider className="flex-1 justify-center items-center">
            <Text className="text-3xl font-semibold">Login</Text>
            <input type="text" className="w-16"></input>  
            <Touchable>Login</Touchable>     
        </SafeAreaProvider>
    )
}